//Kamil Czajka

class WIELOMIAN{
	public:
		int* tablicaWspolczynnikow;
		int stopien;
		static int przeladowanych;

    int wspolnyDzielnik(int a, int b){
	    while (true){
		    if (a > b){
			    a = a % b;
		    }
		    else{
			    b = b % a;
		    }
		
		    if (a == 0){
			    return b;
		    }
		
		    if (b == 0){
			    return a;
		    }
	    }
    }

    int nwdN(){
        int* poprawneDane = new int[stopien + 1]; 
        int ileLiczb = 0;

        for (int i = 0; i <= stopien; i++){ 
             if (tablicaWspolczynnikow[i] != 0){ 
             	if (tablicaWspolczynnikow[i] < 0){ 
                    poprawneDane[ileLiczb++] = -1 * tablicaWspolczynnikow[i];
                }
                else{
                    poprawneDane[ileLiczb++] = tablicaWspolczynnikow[i];
                }
            }
        }

        if (ileLiczb < 2){
            if (ileLiczb == 0){
                delete[] poprawneDane;
                return -1;
            }
            else{
                int v = poprawneDane[0];
                if (v < 0){
                    v = -1 * v;
                }

                delete[] poprawneDane;
                return v;
            }          
        }         
        
        int w = 1;

        for (int i = 1; i < ileLiczb; i++){   
            if (i == 1){ 
                w = wspolnyDzielnik(poprawneDane[0], poprawneDane[1]);             
            } 
            else{ 
             	w = wspolnyDzielnik(w, poprawneDane[i]);
            }
        }
 	  
 	    delete[] poprawneDane;

        return w;  		  
	}

    void modyfikujStopien(){       
        int j = stopien;  
        
        if (j == 0){
           return;
        }

        while (1){
//            cout << j << " " << tablicaWspolczynnikow[j] << " == 0 ? " << (tablicaWspolczynnikow[j] == 0) << endl;
            if (tablicaWspolczynnikow[j] == 0){ 
                j--;
            }
            else{
//                cout << endl;
                break;
            }
            
            if (j == 0){
                break;
            }
        }


        if (j != stopien){
            int* old = tablicaWspolczynnikow;
            stopien = j;
            tablicaWspolczynnikow = new int[stopien + 1];
            for (int i = 0; i <= stopien; i++){
//                cout << tablicaWspolczynnikow[i] << " " << old[i] << endl;
                tablicaWspolczynnikow[i] = old[i];
            }
            delete[] old;     
        }
    }    

    void zmienWspolczynniki(){
        int value = nwdN();
        if (value == -1){
           return;
        }

        for (int i = 0; i <= stopien; i++){
            tablicaWspolczynnikow[i] /= value;
        }
    }    

    WIELOMIAN dzielenie(const WIELOMIAN& w2, bool b){
           WIELOMIAN wielomian;           
           
           if (stopien < w2.stopien){
               if (b == false){
                   wielomian.stopien = stopien;
                   wielomian.tablicaWspolczynnikow = new int[stopien + 1];
                   
                   for (int i = 0; i <= stopien; i++){
                        wielomian.tablicaWspolczynnikow[i] = tablicaWspolczynnikow[i];
                   }
                   
                   return wielomian;  
               }
               else{
                   return wielomian;
               }
           }    
       
           int* licznikWyniku = new int[stopien - w2.stopien + 1];
           int* mianownikWyniku = new int[stopien - w2.stopien + 1];
           int* licznikReszty = new int[stopien + 1];
           int* mianownikReszty = new int[stopien + 1];
           
           for (int i = 0; i <= stopien - w2.stopien; i++){ 
               licznikWyniku[i] = 0;
               mianownikWyniku[i] = 1;
           }
 
           for (int i = 0; i <= stopien; i++){
               licznikReszty[i] = tablicaWspolczynnikow[i];
               if (licznikReszty[i] == 1)
                   mianownikReszty[i] = 0;
               else
                   mianownikReszty[i] = 1;
           }

           bool first = true;
           for (int i = stopien - w2.stopien, j = stopien, k = w2.stopien; i >= 0; i--, j--, k--){
               mianownikWyniku[i] = w2.tablicaWspolczynnikow[k];
               licznikWyniku[i] = licznikReszty[j];
                
      //         cout << "mianownikWyniku[" << i << "] = " << mianownikWyniku[i] << "   licznikWyniku[" << i << "] = " << licznikWyniku[i] << endl;               
            
               for (int l = stopien, m = w2.stopien; m >= 0; l--, m--){
                   if (mianownikReszty[i] == 0){
                      
licznikReszty[l] = (mianownikWyniku[i] * licznikReszty[l] - licznikWyniku[i] * w2.tablicaWspolczynnikow[m]);      
        //           cout << "mianownikReszty[" << l << "] = " << mianownikReszty[l] << " licznikReszty[" << l << "] = " << licznikReszty[l] << endl;              
 mianownikReszty[i] = mianownikWyniku[i]; 
                   }
                   else{ 
                       mianownikReszty[l] *= mianownikWyniku[i];
                   licznikReszty[l] = (mianownikWyniku[i] * licznikReszty[l] - licznikWyniku[i] * w2.tablicaWspolczynnikow[m]);      
          //         cout << "mianownikReszty[" << l << "] = " << mianownikReszty[l] << " licznikReszty[" << l << "] = " << licznikReszty[l] << endl;               
                   }
                        
               }
            //   cout << endl;
           }

           if (b == true){
               wielomian.stopien = stopien - w2.stopien;
               wielomian.tablicaWspolczynnikow = new int[wielomian.stopien + 1];

               for (int i = 0; i <= wielomian.stopien; i++){
                   wielomian.tablicaWspolczynnikow[i] = licznikWyniku[i];
               } 
   
               delete[] licznikWyniku;
               delete[] mianownikWyniku;
               delete[] licznikReszty;
               delete[] mianownikReszty;

               return wielomian;
           }
           else{
               wielomian.stopien = stopien;
               wielomian.tablicaWspolczynnikow = new int[wielomian.stopien + 1];

               for (int i = 0; i <= wielomian.stopien; i++){
                   wielomian.tablicaWspolczynnikow[i] = licznikReszty[i];
               } 
   
               delete[] licznikWyniku;
               delete[] mianownikWyniku;
               delete[] licznikReszty;
               delete[] mianownikReszty;

               return wielomian;
           }
    }    


    WIELOMIAN(){
	tablicaWspolczynnikow = new int[1];
	tablicaWspolczynnikow[0] = 0; 
	stopien = 0; 
    }       

	WIELOMIAN(int n, ...){
		stopien = n;
		tablicaWspolczynnikow = new int[++n];
		va_list args;
		va_start(args, n);

		for (int i = 0; i < n; i++){
			tablicaWspolczynnikow[i] = va_arg(args, int);
		}

		va_end(args);
        
        modyfikujStopien();
        zmienWspolczynniki();
	}

	WIELOMIAN& operator=(const WIELOMIAN& w2){     
        if (&w2 == this){
           return *this;
        }
//        cout << "OK";
        if (tablicaWspolczynnikow != NULL){
            delete[] tablicaWspolczynnikow;            
        }
//cout << "OK";
        stopien = w2.stopien;
        tablicaWspolczynnikow = new int[stopien + 1];
//cout << "OK";     
        for (int i = 0; i <= stopien; i++){
            tablicaWspolczynnikow[i] = w2.tablicaWspolczynnikow[i]; 
        }  
//cout << "OK"; 
        modyfikujStopien();
//cout << "OK";
        zmienWspolczynniki();
//cout << "OK";
        return *this;
	}

	WIELOMIAN operator+(const WIELOMIAN& w2){
        WIELOMIAN wielomian;
        
        if (stopien < w2.stopien){
            wielomian.stopien = w2.stopien;
            wielomian.tablicaWspolczynnikow = new int[wielomian.stopien + 1]; 

            for (int i = 0; i <= w2.stopien; i++){
                if (i <= stopien){
                    wielomian.tablicaWspolczynnikow[i] = tablicaWspolczynnikow[i] + w2.tablicaWspolczynnikow[i];  
                }
                else{
                    wielomian.tablicaWspolczynnikow[i] = w2.tablicaWspolczynnikow[i];
                } 
            }	
        }
        else{
            wielomian.stopien = stopien;
            wielomian.tablicaWspolczynnikow = new int[wielomian.stopien + 1];  

            for (int i = 0; i <= stopien; i++){
                if (i <= w2.stopien){
                    wielomian.tablicaWspolczynnikow[i] = tablicaWspolczynnikow[i] + w2.tablicaWspolczynnikow[i];
                }
                else{
                    wielomian.tablicaWspolczynnikow[i] = tablicaWspolczynnikow[i];
                }	
            }
        }

        wielomian.modyfikujStopien();
        wielomian.zmienWspolczynniki();
//    cout << wielomian;    
	    return wielomian;  		
	}

	WIELOMIAN operator-(const WIELOMIAN& w2){
        WIELOMIAN wielomian;
     
        if (stopien < w2.stopien){
            wielomian.stopien = w2.stopien;
            wielomian.tablicaWspolczynnikow = new int[wielomian.stopien + 1]; 

            for (int i = 0; i <= w2.stopien; i++){
                if (i <= stopien){
                    wielomian.tablicaWspolczynnikow[i] = tablicaWspolczynnikow[i] - w2.tablicaWspolczynnikow[i];  
                }
                else{
                    wielomian.tablicaWspolczynnikow[i] = -1 * w2.tablicaWspolczynnikow[i];
                } 
            }	
        }
        else{
            wielomian.stopien = stopien;
            wielomian.tablicaWspolczynnikow = new int[wielomian.stopien + 1];  
         
            for (int i = 0; i <= stopien; i++){
                if (i <= w2.stopien){
                    wielomian.tablicaWspolczynnikow[i] = tablicaWspolczynnikow[i] - w2.tablicaWspolczynnikow[i];
                }
                else{
                    wielomian.tablicaWspolczynnikow[i] = tablicaWspolczynnikow[i];
                }	
            }
        }

        wielomian.modyfikujStopien();
        wielomian.zmienWspolczynniki();        

	    return wielomian;	   
	}

	WIELOMIAN operator-(){
	    WIELOMIAN wielomian;

	    wielomian.stopien = stopien;
        wielomian.tablicaWspolczynnikow = new int[stopien + 1];

        for (int i = 0; i <= wielomian.stopien; i++){
             wielomian.tablicaWspolczynnikow[i] = -1 * tablicaWspolczynnikow[i];
        }

        wielomian.modyfikujStopien();
        wielomian.zmienWspolczynniki();

	    return wielomian;  
	}

	WIELOMIAN operator*(const WIELOMIAN& w2){
        WIELOMIAN wielomian;

        wielomian.stopien = stopien + w2.stopien;
        wielomian.tablicaWspolczynnikow = new int[wielomian.stopien + 1]; 

        for (int i = 0; i <= wielomian.stopien; i++){
            wielomian.tablicaWspolczynnikow[i] = 0;
        } 
         
        for (int i = 0; i <= stopien; i++){
            for (int j = 0; j <= w2.stopien; j++){
                wielomian.tablicaWspolczynnikow[i + j] += (tablicaWspolczynnikow[i] * w2.tablicaWspolczynnikow[j]);                
            }
        }        
                                    
        wielomian.modyfikujStopien();
        wielomian.zmienWspolczynniki(); 
        return wielomian;  
	}

	WIELOMIAN operator/(const WIELOMIAN& w2){
        WIELOMIAN wielomian = dzielenie(w2, true);
//cout << "EEE";    
        wielomian.modyfikujStopien();
        wielomian.zmienWspolczynniki();
//cout << " XXX"; 
        return wielomian;
	}

	WIELOMIAN operator%(const WIELOMIAN& w2){
        WIELOMIAN wielomian = dzielenie(w2, false);    
        wielomian.modyfikujStopien();
        wielomian.zmienWspolczynniki(); 
        return wielomian;
	}

	WIELOMIAN operator<<(int x){
		WIELOMIAN wielomian;
//       cout << " << " << endl;
        if (x == 0){ 
			wielomian.stopien = stopien;
            wielomian.tablicaWspolczynnikow = new int[wielomian.stopien + 1];

            for (int i = 0; i <= stopien; i++){ 
                wielomian.tablicaWspolczynnikow[i] = tablicaWspolczynnikow[i];
            }

            return wielomian; 
		}

        if (x < 0){ 
            wielomian.stopien = 0;
            wielomian.tablicaWspolczynnikow = new int[1];
            wielomian.tablicaWspolczynnikow[0] = 0;
          
            return wielomian; 
        }
	         
        wielomian.stopien = stopien + x;
        wielomian.tablicaWspolczynnikow = new int[wielomian.stopien + 1];

        for (int i = 0, j = 0; i <= wielomian.stopien; i++){
            if (i < x){
                wielomian.tablicaWspolczynnikow[i] = 0;
            }
            else{
                wielomian.tablicaWspolczynnikow[i] = tablicaWspolczynnikow[j];
//                cout << wielomian.tablicaWspolczynnikow[i] << " = " << tablicaWspolczynnikow[j] << endl;
                j++;
            }     
        }        
        
        wielomian.modyfikujStopien();
        wielomian.zmienWspolczynniki(); 
	    return wielomian; 
	}	

	WIELOMIAN operator>>(int x){
		WIELOMIAN wielomian;
//        cout << " >> " << endl;
        if (x == 0){       
            wielomian.stopien = stopien;
            wielomian.tablicaWspolczynnikow = new int[wielomian.stopien + 1];

            for (int i = 0; i <= stopien; i++){ 
                wielomian.tablicaWspolczynnikow[i] = tablicaWspolczynnikow[i];
            }
      
            return wielomian; 
		}
			
        if (x > stopien || x < 0){ 
              wielomian.stopien = 0;
              wielomian.tablicaWspolczynnikow = new int[1];
              wielomian.tablicaWspolczynnikow[0] = 0;                   	          
              return wielomian;
        }
        
        wielomian.stopien = stopien - x;
        wielomian.tablicaWspolczynnikow = new int[wielomian.stopien + 1]; 
      
        for (int i = 0; i <= wielomian.stopien; i++){
         //    cout << i << " "; 
             wielomian.tablicaWspolczynnikow[i] = tablicaWspolczynnikow[i + x];
        //     cout << i << " " << wielomian.tablicaWspolczynnikow[i] << " = " << i + x << " " << tablicaWspolczynnikow[i + x] << endl;  
        }
        
        wielomian.modyfikujStopien();
        wielomian.zmienWspolczynniki();                
        return wielomian;
	}

	WIELOMIAN& operator+=(const WIELOMIAN& w2){
		*this = *this + w2;
        modyfikujStopien();
        zmienWspolczynniki();
cout << "GGG"; 
		return *this; 
	}

	WIELOMIAN& operator-=(const WIELOMIAN& w2){
	    *this = *this - w2; 
        modyfikujStopien();
        zmienWspolczynniki();
	    return *this; 
	}

	WIELOMIAN& operator*=(const WIELOMIAN& w2){
        *this = *this * w2;
        modyfikujStopien();
        zmienWspolczynniki();
	    return *this; 
	}

	WIELOMIAN& operator/=(const WIELOMIAN& w2){
	    *this = *this / w2;
            modyfikujStopien();
            zmienWspolczynniki();
	    return *this; 
	}

	WIELOMIAN& operator%=(const WIELOMIAN& w2){
	    *this = *this % w2;
            modyfikujStopien();
            zmienWspolczynniki();
	    return *this; 
	}

	WIELOMIAN& operator<<=(int x){
	    *this = *this << x;
            modyfikujStopien();
            zmienWspolczynniki();
	    return *this; 
	}

	WIELOMIAN& operator>>=(int x){
	    *this = *this >> x;
            modyfikujStopien();
            zmienWspolczynniki();
	    return *this; 
	}

	WIELOMIAN& operator++(){
//       cout << 0 << endl;
        for (int i = 0; i <= stopien; i++){            
            ++tablicaWspolczynnikow[i];       
        }

        modyfikujStopien();
        zmienWspolczynniki();

        return *this;
	}

	WIELOMIAN& operator--(){
//        cout << 1 << endl;    
        for (int i = 0; i <= stopien; i++){
            --tablicaWspolczynnikow[i];        
        }
   
        modyfikujStopien();
        zmienWspolczynniki();  

        return *this;
	}

	WIELOMIAN operator++(int){
//        cout << 2 << endl;
        WIELOMIAN wielomian;
	    wielomian.stopien = stopien;
	    wielomian.tablicaWspolczynnikow = new int[stopien + 1];

        for (int i = 0; i <= stopien; i++){
            wielomian.tablicaWspolczynnikow[i] = tablicaWspolczynnikow[i];
            ++tablicaWspolczynnikow[i];                
        }

        modyfikujStopien();
        zmienWspolczynniki();

        return wielomian;
	}

	WIELOMIAN operator--(int){
//        cout << 3 << endl;
        WIELOMIAN wielomian;
	    wielomian.stopien = stopien;
	    wielomian.tablicaWspolczynnikow = new int[stopien + 1];

    	for (int i = 0; i <= stopien; i++){
            wielomian.tablicaWspolczynnikow[i] = tablicaWspolczynnikow[i];
            --tablicaWspolczynnikow[i];                 
        }

        modyfikujStopien();
        zmienWspolczynniki(); 

        return wielomian;
	}

	void* operator new(size_t rozmiar){
	    przeladowanych++;

	    return (::new char[rozmiar]);
	}

	void operator delete(void* wsk){        
        przeladowanych--;

        ::delete wsk; 
	}

	~WIELOMIAN(){
//	cout << "usuwam (";
//        for (int i = 0; i <= stopien; i++){
//            cout << " " << tablicaWspolczynnikow[i];
//            if (i != stopien){
//                cout << ",";
//            }
//        }
//        cout << " ) \n\n";
	    delete[] tablicaWspolczynnikow;
	}

        friend istream& operator>>(istream& in, WIELOMIAN& w);
        friend ostream& operator<<(ostream& out, const WIELOMIAN& w);	
};

istream& operator>>(istream& in, WIELOMIAN& w){
	int n;
	in >> n;

	w.stopien = n;
    int* old = w.tablicaWspolczynnikow;
    w.tablicaWspolczynnikow = new int[w.stopien + 1];
    if (old != NULL){
        delete[] old;
    }

	for (int i = 0; i < w.stopien + 1; i++){
		in >> w.tablicaWspolczynnikow[i];
    }

    w.modyfikujStopien();
    w.zmienWspolczynniki();

    return in;
}

ostream& operator<<(ostream& out, const WIELOMIAN& w){
	out << "(";
//    cout << w.stopien << " ";
	for (int i = 0; i <= w.stopien; i++){
//        cout << "x" << w.tablicaWspolczynnikow[i] << " ";
		out << " " << w.tablicaWspolczynnikow[i];
		if (i != w.stopien){
			out << ",";
		}
	}
	out << " )";

	return out;
}

bool operator<(const WIELOMIAN& w, const WIELOMIAN& w2){
    if (w.stopien < w2.stopien){
        return true;
    }
    else{
        if (w.stopien == w2.stopien){
            for (int i = w.stopien; i >= 0; i--){
                if (w.tablicaWspolczynnikow[i] < w2.tablicaWspolczynnikow[i]){
                    return true;
                }      
            }
        }     
    }    

	return false;
}

bool operator<=(const WIELOMIAN& w, const WIELOMIAN& w2){
    if (w.stopien < w2.stopien){
        return true;
    }
    else{
        if (w.stopien == w2.stopien){
            for (int i = w.stopien; i >= 0; i--){
                if (w.tablicaWspolczynnikow[i] > w2.tablicaWspolczynnikow[i]){
                    return false;
                }      
            }
            return true;
        }     
    } 

	return false;
}

bool operator==(const WIELOMIAN& w, const WIELOMIAN& w2){
    if (w.stopien != w2.stopien){
        return false;
    }
    else{
        for (int i = w.stopien; i >= 0; i--){
            if (w.tablicaWspolczynnikow[i] != w2.tablicaWspolczynnikow[i]){
                return false;                                      
            }      
        }
    } 

	return true;
}

bool operator>=(const WIELOMIAN& w, const WIELOMIAN& w2){
    if (w < w2){  
	    return false;
    } 
    else{
        return true;
    } 
}

bool operator>(const WIELOMIAN& w, const WIELOMIAN& w2){
    if (w <= w2){ 
	    return false;
	}     
    else{ 
    	return true;
    } 
}

bool operator!=(const WIELOMIAN& w, const WIELOMIAN& w2){
    if (w == w2){ 
 	    return false;
    } 
    else{ 
    	return true;
    } 
}
